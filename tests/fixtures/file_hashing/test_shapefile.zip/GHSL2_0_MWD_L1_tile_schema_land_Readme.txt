The shapefile included in this archive has been produced to complement the GHSL 2.0 data, released in 2022 by the GHSL team.
Purpose of the shapefile is to facilitate the download of the data by tiles from the webpage: https://ghsl.jrc.ec.europa.eu/download.php (Mollweide coordinate system). 
It matches tthe tiling schema proposed for downloading local areas. The user can use it off line to identify the desired tiles and then select them accordingly on the download page.
More details about the GHSL 2.0 data release can be found in the attached PDF file.
For more work of the GHSL team, data updates, news and documentation, please refer to our website:
https://ghsl.jrc.ec.europa.eu/.
